After installing Neo4j, you can rebuild the StopKB database by putting the .csv files in the neo4j "import" folder.
The file "import_StopKB.cql" contains the cypher queries used to build the database.
